package com.booktracker.services;

import com.booktracker.entity.Book;
import com.booktracker.repository.BookRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    private final BookRepository bookRepository;

    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // GET all books
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    // GET book by ID
    public Optional<Book> getBookById(Long id) {
        return bookRepository.findById(id);
    }

    // CREATE book
    public Book createBook(Book book) {
        return bookRepository.save(book);
    }

    // UPDATE book
    public Book updateBook(Long id, Book updatedBook) {
        return bookRepository.findById(id)
                .map(book -> {
                    book.setTitle(updatedBook.getTitle());
                    book.setAuthor(updatedBook.getAuthor());
                    book.setGenre(updatedBook.getGenre());
                    book.setYear(updatedBook.getYear());
                    book.setDescription(updatedBook.getDescription());
                    book.setPic(updatedBook.getPic());
                    book.setLangue(updatedBook.getLangue());
                    return bookRepository.save(book);
                }).orElseThrow(() -> new RuntimeException("Book not found with id " + id));
    }

    // DELETE book
    public void deleteBook(Long id) {
        if (!bookRepository.existsById(id)) {
            throw new RuntimeException("Book not found with id " + id);
        }
        bookRepository.deleteById(id);
    }
}
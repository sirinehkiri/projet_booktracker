package com.booktracker.controller;

import com.booktracker.entity.Book;
import com.booktracker.services.BookService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

 private final BookService bookService;

 public BookController(BookService bookService) {
  this.bookService = bookService;
 }

 @GetMapping
 public ResponseEntity<List<Book>> getAllBooks() {
  return ResponseEntity.ok(bookService.getAllBooks());
 }

 @GetMapping("/{id}")
 public ResponseEntity<Book> getBookById(@PathVariable Long id) {
  return bookService.getBookById(id)
          .map(ResponseEntity::ok)
          .orElseThrow(() -> new RuntimeException("Book not found"));
 }

 @PreAuthorize("hasRole('ADMIN')")
 @PostMapping
 public ResponseEntity<Book> createBook(@RequestBody Book book) {
  return ResponseEntity.ok(bookService.createBook(book));
 }

 @PreAuthorize("hasRole('ADMIN')")
 @PutMapping("/{id}")
 public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book book) {
  return ResponseEntity.ok(bookService.updateBook(id, book));
 }

 @PreAuthorize("hasRole('ADMIN')")
 @DeleteMapping("/{id}")
 public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
  bookService.deleteBook(id);
  return ResponseEntity.noContent().build();
 }
}